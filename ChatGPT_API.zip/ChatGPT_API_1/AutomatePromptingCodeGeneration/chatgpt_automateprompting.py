# Import the generate_code function from ai_coder
from ai_coder import generate_code
import os
import pathlib
import configparser
import re

def clean_string(text):
    # Replace special characters with a space
    text = re.sub('[^a-zA-Z0-9\s]+', ' ', text)
    # Convert to lowercase
    text = text.lower()
    # Remove underscores and single quotes
    text = text.replace('_', '').replace("'", '')
    # Remove extra spaces
    text = re.sub('\s+', '', text).strip()
    return text

dir = os.path.dirname(__file__)
data_dir = pathlib.Path(dir, 'data')

# Create a file named 'api_key' and provide your private API key from the link provided: (https://platform.openai.com/account/api-keys)
f = open(os.path.join(dir,"api_key"), "r")
api_key = f.read()

# Create a ConfigParser object
config = configparser.ConfigParser()
# Read the config file
config.read(os.path.join(dir,"config.ini"))
# Get the properties from the 'ORIGINAL_PROMPT' section
original_prompt_properties = config['ORIGINAL_PROMPT']
# Get the properties from the 'PROMPT' section
prompt_properties = config['PROMPT']
problem_number = 1
# Loop through all the properties and print their names and values
for org_name, org_value in original_prompt_properties.items():
    try:
        # skip problems
        if problem_number != 10:
            problem_number += 1
            continue

        build_file_name = f"p{str(problem_number)}.{clean_string(org_value)}.py"
        print(build_file_name)

        prompt_number = 1
        prompts = []

        # Loop through all the properties and print their names and values
        for prompt_name, prompt_value in prompt_properties.items():

            function_description = ''
            if '_array' in org_name :
                function_description = config['FUNCTION_DESCRIPTION']['function_description_array']
            if '_linked_list' in org_name :
                function_description = config['FUNCTION_DESCRIPTION']['function_description_linked_list']
            elif '_pascal' in org_name :
                function_description = config['FUNCTION_DESCRIPTION']['function_description_pascal']

            prompt_value = prompt_value.replace('<ORIGINAL_PROMPT>',f'{org_value}').replace('<FUNCTION_DESCRIPTION>',f'{function_description}').replace("\'", "")
            # print(prompt_value)
            prompts.append(prompt_value)

            # skip prompts
            if prompt_number <= 6:
                prompt_number += 1
                continue

            generated_code_list = []
            generated_code_list.append(prompt_value)
            for i in range(10):
                try:
                    # print(i)
                    # Call the generate_code function with prior_code=None
                    generated_code = generate_code([], [prompt_value], api_key, checkfn = compile, max_tries=10, temperature=0)
                    # generated_code = str(prompt_number) + str(i) + build_file_name
                    generated_code_list.append(generated_code)
                except Exception as e:
                    print (f"problem_number: {problem_number} - prompt_number: {str(prompt_number)} , Error: {str(e)} ")
                    continue

            filename = os.path.join(data_dir, build_file_name)
            if not os.path.isfile(filename):
                file_mode = "w"
            else:
                file_mode = "a"

            # Store the generated code in a file named after the first human message
            with open(filename, file_mode) as file:
                file.write(f"{str(generated_code_list)}\n")

            prompt_number +=1
        
        # case of prompt ensemble
        generated_code_list = []
        if (prompt_number == 7):
            print (f'problem_number: {problem_number} - prompt_number: {prompt_number}')
            # # Loop through the list, skipping the first prompt, and process the other prompts 2,3,4,5,6 
            for index, prompt_value in enumerate(prompts[1:], start=2):
                # skip python code generation
                if index != 6:
                    continue
                print(index)
                
                generated_code_list.append(f'prompt_ensemble_{index}: {prompt_value}')
                for i in range(2):
                    try:
                        # print(i)
                        # Call the generate_code function with prior_code=None
                        generated_code = generate_code([], [prompt_value], api_key, checkfn = compile, max_tries=10, temperature=0)
                        # generated_code = str(prompt_number) + str(i) + build_file_name
                        generated_code_list.append(generated_code)
                    except Exception as e:
                        print (f"problem_number: {problem_number} - prompt_number: {str(prompt_number)} , Error: {str(e)} ")
                        continue

            filename = os.path.join(data_dir, build_file_name)
            if not os.path.isfile(filename):
                file_mode = "w"
            else:
                file_mode = "a"

            # Store the generated code in a file named after the first human message
            with open(filename, file_mode) as file:
                file.write(f"{str(generated_code_list)}\n")
            
        problem_number +=1
    except Exception as e:
        problem_number +=1
        print (f"\t\t ++++++ Generated_code_list: {str(generated_code_list)} , Error: {str(e)} ")
        continue
         
