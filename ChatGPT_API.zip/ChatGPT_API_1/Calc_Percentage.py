
import os
import pandas as pd
import glob

# Find all CSV files with the substring 'summary_auto_execution_times.csv' in the directory
# file_list = glob.glob('*summary_0-1-6-7_auto_execution_times.csv')
file_list = glob.glob('p15_summary_0-1-6-7_auto_execution_times.csv')

for file in file_list:
    try:
        # Read the data from the CSV file
        df = pd.read_csv(file)
        print(file)
        # Calculate the minimum average per size
        min_avg_df = df.groupby('Size')['Average'].min().reset_index()
        min_avg_df.columns = ['Size', 'Minimum Average']
        # Merge the minimum average DataFrame with the original DataFrame
        merged_df = pd.merge(df, min_avg_df, on='Size', how='left')
        # Calculate the percentage with respect to the minimum average per size
        merged_df['Percentage'] = 100*((merged_df['Average'] - merged_df['Minimum Average']) / merged_df['Minimum Average'] if (merged_df['Minimum Average']!=0).any() else 0)
        # Sort the result by Order
        # result_df = merged_df.sort_values('Prompt','Size')
        # Save the updated result back to the CSV file
        merged_df.to_csv(file, index=False)

    except Exception as e:
        print (f"Error: {str(e)} ")
        continue