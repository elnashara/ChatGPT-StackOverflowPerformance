import pandas as pd
import matplotlib.pyplot as plt
import os

# Create a DataFrame with the given data
data = {
    'Order': [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18],
    'categories': [1000, 10000, 100000, 1000, 10000, 100000, 1000, 10000, 100000, 1000, 10000, 100000, 1000, 10000, 100000, 1000, 10000, 100000],
    'Prompt': ['Prompt_1', 'Prompt_1', 'Prompt_1', 'Prompt_2', 'Prompt_2', 'Prompt_2', 'Prompt_3', 'Prompt_3', 'Prompt_3', 'Prompt_4', 'Prompt_4', 'Prompt_4', 'Prompt_5', 'Prompt_5', 'Prompt_5', 'Prompt_6', 'Prompt_6', 'Prompt_6'],
    'percentage of times': [0, 0, 0, 340.8756457, 332.0705834, 81.02805909, 417.8281595, 441.2152299, 149.8998843, 510.0353779, 511.0428243, 131.4947746, 575.4387364, 568.494583, 175.7764954, 9.91246865, 6.91925283, 4.734704332]
}
# df = pd.DataFrame(data)

dir = os.path.dirname(__file__)
filename = 'p1_detailed_auto_execution_times.csv'
# Construct the full file path
file_path = os.path.join(dir, filename)

# Read data from file
df = pd.read_csv(file_path)

# # Determine the minimum and maximum values from the data
# min_value = df['percentage of times'].min()
# max_value = df['percentage of times'].max()

# # Create the range list with increment of 5
# increment = 5
# ranges = list(range(int(min_value), int(max_value) + increment, increment))


# Define the ranges for counting prompts
ranges = [(0, 5),(5, 10),(10, 50), (50, 100), (100, 200), (200, 300), (300, 3000)]  # You can add more ranges if needed

# Initialize lists to store the counts and percentages
counts = []
percentages = []

total = 6 #6

# Count the number of prompts for each category within each range
for range_start, range_end in ranges:
    count = df[(df['Percentage'] >= range_start) & (df['Percentage'] < range_end)].groupby('Size').size()
    counts.append(count / total * 100) 
    total = count.sum()
    percentage = count / total * 100
    percentages.append(percentage)

# Create a DataFrame to hold the counts
result = pd.concat(counts, axis=1)
result.columns = [f"{range_start}-{range_end}%" for range_start, range_end in ranges]

# Plot the counts
ax = result.plot(kind='bar', stacked=True)
plt.xlabel("Categories")
plt.ylabel("Prompts Percentage %")
plt.title("Percent of Prompts in Specific Percentage of Time Ranges by Categories")

# Add percentages to the bars
for p in ax.patches:
    width = p.get_width()
    height = p.get_height()
    x, y = p.get_xy()
    ax.annotate(f'{height:.1f}%', (x + width / 2, y + height / 2), ha='center', va='center')

# # Draw the range labels on the side
# plt.ylim(0, 100)

# Draw the legend outside the graph
plt.legend(loc="upper right", bbox_to_anchor=(1.30, 1))

plt.show()
