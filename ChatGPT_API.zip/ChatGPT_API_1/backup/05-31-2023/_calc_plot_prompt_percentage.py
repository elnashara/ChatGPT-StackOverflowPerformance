import matplotlib.pyplot as plt

# # Sample data
# data = [
#     (1000, "Prompt_1", 0),
#     (10000, "Prompt_1", 0),
#     (100000, "Prompt_1", 0),
#     (1000, "Prompt_2", 340.8756457),
#     (10000, "Prompt_2", 332.0705834),
#     (100000, "Prompt_2", 81.02805909),
#     (1000, "Prompt_3", 417.8281595),
#     (10000, "Prompt_3", 441.2152299),
#     (100000, "Prompt_3", 149.8998843),
#     (1000, "Prompt_4", 510.0353779),
#     (10000, "Prompt_4", 511.0428243),
#     (100000, "Prompt_4", 131.4947746),
#     (1000, "Prompt_5", 575.4387364),
#     (10000, "Prompt_5", 568.494583),
#     (100000, "Prompt_5", 175.7764954),
#     (1000, "Prompt_6", 9.91246865),
#     (10000, "Prompt_6", 6.91925283),
#     (100000, "Prompt_6", 4.734704332),
# ]

# Step 3: Categorize the prompts
# categories = {
#     "0% slower than optimal": [],
#     "5% slower than optimal": [],
#     "10% slower than optimal": [],
#     "> 10% slower than optimal": [],
# }

import os
import pandas as pd
import glob

# Find all CSV files with the substring 'summary_auto_execution_times.csv' in the directory
# file_list = glob.glob('*summary_auto_execution_times.csv')

file_list = glob.glob('p1-p15-Aggregate_plot_summary_auto_execution_times.csv')

for file in file_list:
    # Read data from file
    df = pd.read_csv(file)
    
    print(file)
    problem_number = file.split('_')[0]
    categories = {
        "0% optimal": [],
        "5% slower": [],
        "10% slower": [],
        "> 10% slower": [],
    }
    
    for _, prompt, percentage in df[['Size', 'Prompt', 'Percentage']].values:
        if percentage == 0:
            categories["0% optimal"].append(prompt)
        elif 0 < percentage <= 5:
            categories["5% slower"].append(prompt)
        elif 5 < percentage <= 10:
            categories["10% slower"].append(prompt)
        else:
            categories["> 10% slower"].append(prompt)
    
    # Step 4: Calculate the percentage of prompts within each category
    total_prompts = len(df)
    percentages = {}
    
    for category, prompts in categories.items():
        prompt_count = len(prompts)
        percentage = (prompt_count / total_prompts) * 100
        percentages[category] = percentage
    
    # Step 5: Graph the data
    x_labels = list(percentages.keys())
    y_values = list(percentages.values())
    
    # plt.bar(x_labels, y_values)
    # plt.xlabel("Categories")
    # plt.ylabel("Percentage")
    # plt.title("Percentage of Prompts within Each Category")
    # plt.show()
    
    # Step 6: Label the graph
    plt.bar(x_labels, y_values)
    plt.xlabel("Categories")
    plt.ylabel("Percentage")
    plt.title(f"Problem {problem_number} \n Percentage of Prompts within Each Category")
    

    # Plot the percentages on top of each bar
    for i, v in enumerate(y_values):
        plt.text(i, v, f"{v:.2f}%", ha="center", va="bottom")    
    
    # # Adding a legend
    # legend_labels = ["0% slower than optimal", "5% slower than optimal", "10% slower than optimal", "> 10% slower than optimal"]
    # plt.legend(legend_labels)
    
    # Displaying the graph
    plt.show()
    
