import ast
import os
import pathlib
import re
import random
import statistics
import timeit
import csv
from collections import defaultdict

#**************************************************************
# Problem p9: Count frequency
# Source: ChatGPT API
#**************************************************************

problem_number = 9

problem = f"p{problem_number}_auto_countfrequency_strategy"
output_summary = f"p{problem_number}_summary_auto_execution_times.csv"
output_detailed = f"p{problem_number}_detailed_auto_execution_times.csv"

dir = os.path.dirname(__file__)

# Directory path containing the JSON files
directory_path = pathlib.Path(dir, 'AutomatePromptingCodeGeneration/data/')

prefix = f"p{problem_number}."
suffix = ".py"

# Loop through all the files in the directory
for filename in os.listdir(directory_path):
    # Check if the file has a .json extension
    if filename.startswith(prefix) and filename.endswith(suffix):
        # Construct the full file path
        file_path = os.path.join(directory_path, filename)
        
        print(file_path)

        # Open the file in read mode
        with open(file_path, 'r') as file:
            # Read the file content
            file_content = file.read().splitlines()

            p_result_list = []
            function_index = 1
            for content in file_content:
                # if function_index != 7:
                #     function_index += 1
                #     continue

                data_content = content.split("prompt_ensemble_")
                for sub in data_content:
                    split_strings = sub.split("\'code\':")

                    prompt = split_strings[0].strip("['\\]").strip().replace("', {", "") 
                    # print(prompt)
                    
                    sample_index = 1
                    for data in split_strings[1:]:
                        # print ("{'code':" + data)
                        print(f"function_index: {function_index}")
                        try:
                            code_start_index = data.replace("```python","```Python").find("```Python")
                            if code_start_index > 0: 
                                print(sample_index)
                                code_end_index = data.find("```", code_start_index + len("```Python"))
                                code_string = data[code_start_index + len("```Python"):code_end_index]
                                # Cleaning up the code string and replacing "\n" with actual newline character
                                code_string = code_string.strip().replace("\\n", "\n")
                                # Removing escape sequences
                                code_string = code_string.encode().decode('unicode_escape')
                                # Evaluating the code string and capturing the AST
                                code_ast = ast.parse(code_string, mode='exec')
                                # Extracting the source code from the AST
                                code_segment = ast.unparse(code_ast)
                                # Accessing the extracted code
                                # print(code_segment)

                                # Executing the code segment
                                exec(code_segment)

                                # # Example data
                                # arr = [5, 1, 2, 2, 4, 3, 1, 2, 3, 1, 1, 5, 2]
                                # # Calling the function with example data
                                # result = funcImp(arr)
                                # # Printing the result
                                # print("\t\tInput:", arr)
                                # print("\t\tResult:", result)
                                # del result
                                
                                #**************************************************************
                                sizes = [1000, 10000, 100000]
                                versions = 100

                                for size in sizes:
                                    time_list = []
                                    print(f"\t\tTesting for list size {size}")
                                    for i in range(versions):

                                        lst = [random.randint(0, 1000000) for _ in range(size)]

                                        time_res = timeit.timeit(lambda: funcImp(lst), number=100)
                                        time_list.append(time_res)
                                        del time_res
                                        
                                    min_time = min(time_list)
                                    avg_time = statistics.mean(time_list)
                                    max_time = max(time_list)

                                    result = {
                                        'function_index': function_index,
                                        'prompt': prompt,
                                        'code_segment': str(code_segment),
                                        'sample_index': sample_index,
                                        'size': size,
                                        'min_time': min_time,
                                        'avg_time': avg_time,
                                        'max_time': max_time,
                                        'Exception': 'N/A'
                                    }
                                    p_result_list.append(result)
                                # print(\t\t p_result_list)
                                sample_index+=1
                            else:
                                print(f"\t\t function_index: {function_index} , code_start_index: {code_start_index}")
                                result = {
                                    'function_index': function_index,
                                    'prompt': prompt,
                                    'code_segment': data,
                                    'sample_index': sample_index,
                                    'size': 0,
                                    'min_time': 0,
                                    'avg_time': 0,
                                    'max_time': 0,
                                    'Exception': f"function_index: {function_index} , code_start_index: {code_start_index}, No Python code available"
                                }
                                p_result_list.append(result)
                                sample_index+=1
                        except Exception as e:
                            print (f"\t\t function_index: {function_index} , code_start_index: {code_start_index}, Error: {str(e)} ")
                            result = {
                                'function_index': function_index,
                                'prompt': prompt,
                                'code_segment': code_segment,
                                'sample_index': sample_index,
                                'size': 0,
                                'min_time': 0,
                                'avg_time': 0,
                                'max_time': 0,
                                'Exception': f"function_index: {function_index} , code_start_index: {code_start_index}, Error: {str(e)}"
                            }
                            p_result_list.append(result)
                            sample_index +=1
                            continue
                function_index +=1

result = defaultdict(lambda: defaultdict(list))

write_header = False
if not os.path.isfile(os.path.join(dir,output_detailed)):
    write_header = True

# Write a detailed information of the program's runtime to an output file.
with open(os.path.join(dir,output_detailed), mode='a', newline='') as file:
    writer = csv.writer(file)
    if write_header == True:
        writer.writerow(['function_index', 'prompt', 'sample_index', 'code_segment', 'Size', 'Min', 'Average', 'Max', 'Exception'])

    for row in p_result_list:
        function_index = row['function_index']
        size = row['size']
        code_segment_lines = row['code_segment'].split("\n")
        code_segment = ([code_segment] for code_segment in code_segment_lines)
        
        prompt = row['prompt']
        result[(function_index, size)]['min_time'].append(row['min_time'])
        result[(function_index, size)]['avg_time'].append(row['avg_time'])
        result[(function_index, size)]['max_time'].append(row['max_time'])

        writer.writerow([str(function_index)  + "_" + problem, prompt, row['sample_index'], [row['code_segment']] , size,  row['min_time'], row['avg_time'], row['max_time'], row['Exception']])

write_header = False
if not os.path.isfile(os.path.join(dir,output_summary)):
    write_header = True
# Write a summary information of the program's runtime to an output file.
with open(os.path.join(dir,output_summary), mode='a', newline='') as file:
    writer = csv.writer(file)
    if write_header == True:
        writer.writerow(['Size', 'Prompt', 'Function', 'Min', 'Average', 'Max'])
    for (function_index, size), times in result.items():
        print(f"Size: {size}")
        print(f"Prompt: f'Prompt_{str(function_index)}'")
        # print(f"Prompt: f'Prompt_{str(prompt)}'")
        
        print(f"function Index: {function_index}")
        min_time = min(times['min_time'])
        avg_time = sum(times['avg_time'])/len(times['avg_time'])
        max_time = max(times['max_time'])

        print(f"Min of min_time: {min_time}")
        print(f"Avg of avg_time: {avg_time}")
        print(f"Max of max_time: {max_time}")
        print()

        writer.writerow([size,f'Prompt_{str(function_index)}', str(function_index)  + "_" + problem , min_time, avg_time, max_time])

import pandas as pd
try:
    # Read the data from the CSV file
    file = os.path.join(dir,output_summary)
    df = pd.read_csv(file)
    print(file)
    # Calculate the minimum average per size
    min_avg_df = df.groupby('Size')['Average'].min().reset_index()
    min_avg_df.columns = ['Size', 'Minimum Average']
    # Merge the minimum average DataFrame with the original DataFrame
    merged_df = pd.merge(df, min_avg_df, on='Size', how='left')
    # Calculate the percentage with respect to the minimum average per size
    merged_df['Percentage'] = 100*((merged_df['Average'] - merged_df['Minimum Average']) / merged_df['Minimum Average'] if (merged_df['Minimum Average']!=0).any() else 0)
    # Sort the result by Order
    # result_df = merged_df.sort_values('Prompt','Size')
    # Save the updated result back to the CSV file
    merged_df.to_csv(file, index=False)
except Exception as e:
    print (f"Error: {str(e)} ")