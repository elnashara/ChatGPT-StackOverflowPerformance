import matplotlib.pyplot as plt
import numpy as np

# data = np.array([[0.0, 100.0, 200.0, 300.0],
#                  [20.0, 0.0, 40.0, 60.0],
#                  [33.33333333, 11.11111111, 22.22222222, 0.0]])


data = [
    (1000, 1),
    (10000, 6),
    (100000, 12),
    (1000, 2),
    (10000, 5),
    (100000, 10),
    (1000, 3),
    (10000, 7),
    (100000, 11),
    (1000, 4),
    (10000, 8),
    (100000, 9)
]

averages = {}
percentage_diffs = {}

# Calculate the minimum average for each size
for size, average in data:
    if size not in averages or average < averages[size]:
        averages[size] = average

# Calculate the percentage difference for other data with the same size
for size, average in data:
    min_avg = averages[size]
    percentage_diff = abs((average - min_avg) / min_avg) * 100
    if size not in percentage_diffs:
        percentage_diffs[size] = []
    percentage_diffs[size].append(percentage_diff)

# Prepare data for stacked bar chart
sizes = sorted(averages.keys())
labels = ['Data {}'.format(i + 1) for i in range(len(data) // len(sizes))]
percentage_values = np.array([percentage_diffs[size] for size in sizes])

data = percentage_values 

# labels = ['Data 1', 'Data 2', 'Data 3']  # Labels for each category

x = np.arange(data.shape[1])  # x-axis values
width = 0.35  # Width of each bar

# Plot the stacked bar chart
fig, ax = plt.subplots()
bars = []
bottom = np.zeros(data.shape[1])  # Bottom values for stacking the bars

# Iterate through each row of data
for i in range(data.shape[0]):
    bar = ax.bar(x, data[i], width, bottom=bottom, label=labels[i])
    bars.append(bar)
    bottom += data[i]  # Update the bottom values for the next row

# Set labels, title, and legend
ax.set_xlabel('Categories')
ax.set_ylabel('Values')
ax.set_title('Stacked Bar Chart')
ax.set_xticks(x)
ax.set_xticklabels(['Category 1', 'Category 2', 'Category 3', 'Category 4'])
ax.legend()

# Add labels to the bars
for bar in bars:
    for rect in bar:
        height = rect.get_height()
        ax.annotate(f'{height:.2f}', xy=(rect.get_x() + rect.get_width() / 2, height),
                    xytext=(0, 3), textcoords='offset points', ha='center', va='bottom')

plt.show()
