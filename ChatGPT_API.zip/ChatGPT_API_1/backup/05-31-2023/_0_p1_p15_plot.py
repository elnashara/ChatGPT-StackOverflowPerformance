import pandas as pd
import matplotlib.pyplot as plt


def plot(data, title):
    # Group the data by Function
    grouped_data = data.groupby('Prompt')
    
    # Create a figure and axes
    fig, ax = plt.subplots()
    
    # Plot each group separately
    for group_name, group_data in grouped_data:
        ax.plot(group_data['Size'], group_data['Average'], label=group_name)
    
    # Add labels and title
    ax.set_xlabel('Size')
    ax.set_ylabel('Average')
    ax.set_title(f'Average Time for {title}')
    
    # Add legend
    ax.legend()
    
    # Show the plot
    plt.show()
    
for index in range(1, 16):
    if index in (1, 2, 3, 4, 5, 6, 7, 8 , 9, 10, 11, 12, 13, 14, 15):
        # Load data from CSV file
        file_name = f'p{index}_summary_auto_execution_times.csv'
        data = pd.read_csv(f'D:\chatGPT-humanExpert\ChatGPT_API\{file_name}')
        
        title = data['Function'][0].replace('_auto_',' ').split('1_p')[1]
        plot(data, f'Problem_{title}')
    # break
    # print(index)
    
    


# file_name, title = '2_summary_auto_execution_times.csv', 'Problem-2 Finding Duplicate Number'
# data = pd.read_csv(f'D:\chatGPT-humanExpert\ChatGPT_API\{file_name}')
# plot(data, title)

# file_name, title = '5_summary_auto_execution_times.csv', 'Problem-5 Finding Duplicates'
# data = pd.read_csv(f'D:\chatGPT-humanExpert\ChatGPT_API\{file_name}')
# plot(data, title)

# problem_number, title = 2, 'Problem-2 Finding Duplicate Number'

# problem_number, title = 5, 'Problem-5 Finding Duplicates'
# problem_number, title = 6, 'Problem-6 Removing Duplicates'


