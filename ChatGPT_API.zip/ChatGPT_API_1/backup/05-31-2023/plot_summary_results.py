import matplotlib.pyplot as plt
import pandas as pd

import os
import glob

# Sample data
data = {
    'Prompt': ['Prompt_1', 'Prompt_1', 'Prompt_1', 'Prompt_2', 'Prompt_2', 'Prompt_2',
               'Prompt_3', 'Prompt_3', 'Prompt_3', 'Prompt_4', 'Prompt_4', 'Prompt_4',
               'Prompt_5', 'Prompt_5', 'Prompt_5', 'Prompt_6', 'Prompt_6', 'Prompt_6'],
    'Percentage': [0, 0, 0, 340.8756457, 332.0705834, 81.02805909, 417.8281595,
                   441.2152299, 149.8998843, 510.0353779, 511.0428243, 131.4947746,
                   575.4387364, 568.494583, 175.7764954, 9.91246865, 6.91925283,
                   4.734704332]
}

# # Convert data to a DataFrame
# df = pd.DataFrame(data)


# Find all CSV files with the substring 'summary_auto_execution_times.csv' in the directory
# file_list = glob.glob('*summary_auto_execution_times.csv')
# 'p1-p15-Aggregate_plot_summary_auto_execution_times.csv'
file_list = glob.glob('*summary_auto_execution_times.csv')
# file_list = glob.glob('p2_summary_auto_execution_times.csv')


for file in file_list:
    # Read data from file
    df = pd.read_csv(file)
    
    print(file)
    problem_number = file.split('_')[0]

    # Calculate the percentage difference
    optimal_time = df['Percentage'].min()
    # df['Percentage Difference'] = ((df['Percentage'] - optimal_time) / optimal_time) * 100
    
    # Define the categories
    categories = {
        '0% Optimal': lambda x: x == 0,
        '5% Slower': lambda x: 0 < x <= 5,
        '10% Slower': lambda x: 5 < x <= 10,
        '> 10% Slower': lambda x: x > 10
    }
    
    # Convert 'Prompt' column to a categorical data type with desired order
    category_order = list(categories.keys())
    # df['Prompt'] = pd.Categorical(df['Prompt'], categories=category_order, ordered=True)

    # Categorize the prompts
    df['Category'] = df.groupby('Prompt')['Percentage'].apply(
        lambda x: x.apply(lambda y: next((category for category, condition in categories.items() if condition(y)), None))
    )
    
    # Calculate the percentage of prompts in each category
    category_counts = df.groupby(['Prompt', 'Category']).size().unstack(fill_value=0)
    category_percentages = category_counts.div(category_counts.sum(axis=1), axis=0) * 100
    
    # Create the stacked bar chart
    ax = category_percentages.plot(kind='bar', stacked=True, colormap='tab20', width=0.8)
    
    plt.xlabel('Prompt')
    plt.ylabel('Percentage')
    plt.title(f"Problem {problem_number} \n Performance Comparison of Prompts")
    # plt.legend(title='Category')
    plt.legend(title='Category', labels=category_order)  # Use sorted categories in legend
    
    # Add percentage labels
    totals = category_counts.sum(axis=1)
    for i, prompt in enumerate(category_percentages.index):
        values = category_percentages.loc[prompt]
        prev_value = 0
        for j, (category, value) in enumerate(values.items()):
            if value == 0.0:
                continue
            ax.text(i, prev_value + value / 2, f'{value:.1f}%', ha='center', va='center')
            prev_value += value
    
    # Draw the legend outside the graph
    plt.legend(loc="upper right", bbox_to_anchor=(1.30, 1))
    
    
    # Display the chart
    plt.show()
